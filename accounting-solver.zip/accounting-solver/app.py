"""
Accounting Solution Generator
-----------------------------
Upload an image/PDF of an accounting assignment (or type a topic), send it to
Google Gemini (gemini-2.5-flash), receive a structured JSON solution, and
download it as a formatted PDF built with ReportLab.
"""

import io
import json
import os
import re
from datetime import datetime
from html import escape

from flask import Flask, jsonify, render_template, request, send_file
from google import genai
from google.genai import types
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    ListFlowable,
    ListItem,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# ---------------------------------------------------------------------------
# App configuration
# ---------------------------------------------------------------------------
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB upload limit

MODEL_NAME = "gemini-2.5-flash"
ALLOWED_MIME_TYPES = {
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/heic",
    "image/heif",
    "application/pdf",
}

# The system prompt tells Gemini exactly what JSON structure to return.
# Asking for JSON lets us build a neatly formatted PDF reliably.
SYSTEM_PROMPT = """You are an expert accounting tutor preparing a complete,
well-structured solution to a university accounting assignment (IFRS/GAAP as appropriate).

If an image or PDF is supplied, read every question carefully and solve each one.
If only a topic is given, create a representative problem on that topic and solve it.

Return ONLY valid JSON in this exact shape (no markdown fences, no commentary):
{
  "title": "Short assignment title",
  "sections": [
    {
      "heading": "Question 1 - Working Notes",
      "blocks": [
        {"type": "paragraph", "text": "Explanation text..."},
        {"type": "bullets", "items": ["point one", "point two"]},
        {"type": "table",
         "headers": ["Date", "Account", "Debit", "Credit"],
         "rows": [["01 Jan 2026", "Cash", "10,000.00", ""]]}
      ]
    }
  ]
}

Rules:
- For each question include: working notes, journal entries, and a concise explanation
  of the accounting treatment.
- Use "table" blocks for journal entries, ledgers, and calculations. Put totals in the last row.
- Format numbers with thousands separators and two decimals.
- Use plain text only: no LaTeX, no markdown symbols such as ** or #.
- Keep explanations clear and concise so a student can learn from them.
"""

# The Gemini client reads the key from the GEMINI_API_KEY environment variable.
_client = None


def get_client():
    """Create the Gemini client on first use so the app still starts without a key."""
    global _client
    if _client is None:
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY environment variable is not set.")
        _client = genai.Client(api_key=api_key)
    return _client


# ---------------------------------------------------------------------------
# Gemini helper
# ---------------------------------------------------------------------------
def generate_solution(topic: str, file_bytes: bytes | None, mime_type: str | None) -> dict:
    """Send the image/PDF and/or topic to Gemini and return the parsed JSON solution."""
    contents = []

    # Multimodal input: attach the image or PDF as a binary part.
    if file_bytes:
        contents.append(types.Part.from_bytes(data=file_bytes, mime_type=mime_type))

    # Text instructions from the student.
    prompt = "Please solve the following accounting assignment."
    if topic:
        prompt += f"\n\nTopic / instructions from the student: {topic}"
    contents.append(prompt)

    response = get_client().models.generate_content(
        model=MODEL_NAME,
        contents=contents,
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            response_mime_type="application/json",  # ask Gemini for raw JSON
            temperature=0.2,                         # lower = more consistent maths
        ),
    )

    # Strip accidental code fences, then parse.
    raw = (response.text or "").strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
    solution = json.loads(raw)

    if "sections" not in solution:
        raise ValueError("Model response is missing the 'sections' field.")
    return solution


# ---------------------------------------------------------------------------
# PDF helpers
# ---------------------------------------------------------------------------
def make_table(block: dict, cell_style: ParagraphStyle) -> Table:
    """Convert a 'table' block from the JSON into a styled ReportLab table."""
    headers = block.get("headers", [])
    rows = block.get("rows", [])

    data = []
    if headers:
        data.append([Paragraph(f"<b>{escape(str(h))}</b>", cell_style) for h in headers])
    for row in rows:
        data.append([Paragraph(escape(str(cell)), cell_style) for cell in row])

    if not data:
        return Spacer(0, 0)

    # Pad short rows so every row has the same number of cells.
    ncols = max(len(r) for r in data)
    for r in data:
        while len(r) < ncols:
            r.append(Paragraph("", cell_style))

    table = Table(data, repeatRows=1 if headers else 0, hAlign="LEFT")
    style = [
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#94a3b8")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    if headers:
        style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e0e7ff")))
    table.setStyle(TableStyle(style))
    return table


def build_pdf(solution: dict) -> io.BytesIO:
    """Render the solution dictionary into a neatly formatted A4 PDF."""
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        leftMargin=20 * mm,
        rightMargin=20 * mm,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
        title=str(solution.get("title", "Accounting Solution")),
    )

    base = getSampleStyleSheet()
    title_style = ParagraphStyle(
        "SolTitle", parent=base["Title"], fontSize=18, leading=22,
        textColor=colors.HexColor("#1e3a8a"), spaceAfter=4,
    )
    meta_style = ParagraphStyle(
        "Meta", parent=base["BodyText"], fontSize=9, textColor=colors.grey, spaceAfter=10,
    )
    heading_style = ParagraphStyle(
        "SecHead", parent=base["Heading2"], fontSize=13, leading=16,
        textColor=colors.HexColor("#1e40af"), spaceBefore=12, spaceAfter=6,
    )
    body_style = ParagraphStyle(
        "Body", parent=base["BodyText"], fontSize=10, leading=14, spaceAfter=6,
    )
    cell_style = ParagraphStyle(
        "Cell", parent=body_style, fontSize=9, leading=12, spaceAfter=0,
    )

    story = [
        Paragraph(escape(str(solution.get("title", "Accounting Solution"))), title_style),
        Paragraph(f"Generated on {datetime.now():%d %b %Y}", meta_style),
    ]

    for section in solution.get("sections", []):
        story.append(Paragraph(escape(str(section.get("heading", ""))), heading_style))

        for block in section.get("blocks", []):
            kind = block.get("type")

            if kind == "paragraph":
                text = escape(str(block.get("text", ""))).replace("\n", "<br/>")
                story.append(Paragraph(text, body_style))

            elif kind == "bullets":
                items = [
                    ListItem(Paragraph(escape(str(item)), body_style))
                    for item in block.get("items", [])
                ]
                story.append(ListFlowable(items, bulletType="bullet", start="•", leftIndent=14))

            elif kind == "table":
                story.append(make_table(block, cell_style))

            story.append(Spacer(1, 6))

    doc.build(story)
    buffer.seek(0)
    return buffer


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/solve", methods=["POST"])
def solve():
    """Receive the topic and/or file, call Gemini, and return the solution as JSON."""
    topic = (request.form.get("topic") or "").strip()
    upload = request.files.get("file")

    file_bytes, mime_type = None, None
    if upload and upload.filename:
        mime_type = upload.mimetype
        if mime_type not in ALLOWED_MIME_TYPES:
            return jsonify(error="Unsupported file type. Please upload PNG, JPG, WEBP or PDF."), 400
        file_bytes = upload.read()

    if not topic and not file_bytes:
        return jsonify(error="Please upload an image or type a topic."), 400

    try:
        solution = generate_solution(topic, file_bytes, mime_type)
        return jsonify(solution=solution)
    except json.JSONDecodeError:
        return jsonify(error="The AI returned an unexpected format. Please try again."), 502
    except Exception as exc:  # keep the message short and user-friendly
        app.logger.exception("Gemini request failed")
        return jsonify(error=f"Could not generate the solution: {exc}"), 500


@app.route("/download-pdf", methods=["POST"])
def download_pdf():
    """Receive the solution JSON from the browser and return a PDF file."""
    solution = request.get_json(silent=True)
    if not solution or "sections" not in solution:
        return jsonify(error="No valid solution provided."), 400

    pdf = build_pdf(solution)
    safe_title = re.sub(r"[^A-Za-z0-9_-]+", "_", str(solution.get("title", "solution")))[:60]
    return send_file(
        pdf,
        mimetype="application/pdf",
        as_attachment=True,
        download_name=f"{safe_title or 'solution'}.pdf",
    )


if __name__ == "__main__":
    app.run(debug=True)
